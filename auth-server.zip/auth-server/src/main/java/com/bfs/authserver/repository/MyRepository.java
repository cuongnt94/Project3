package com.bfs.authserver.repository;


import domain.Employee;

public interface MyRepository {
}
